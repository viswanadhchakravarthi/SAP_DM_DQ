
**Data Profiling Agent.**

It is sequenced from **Highest Priority (Agent Quality & Accuracy Core)** to **Lowest Priority (Export & Packaging)**.

#### **Technical Specification: Agentic Data Profiling Engine**

**To:** AI/ML Engineer

**Objective:** Upgrade the Data Profiling Agent from basic statistical profiling to an intelligent, SAP-aware Data Governance Agent as mandated by the Scoping Document.

---
<!-- 
#### **Priority 1: Deterministic SAP Domain Rule Engine (Core Quality)**

*Stop relying solely on LLMs to generate dynamic Pandas checks. Pre-seed deterministic, rule-based profiling checks:*

1. **Activeness Engine:** Check deletion flags (`LOEVM == 'X'`), posting blocks (`SPERM / SPERR == 'X'`), and creation date (`ERDAT`) aging (>3 years inactive).


2. **Completeness Engine:** Enforce mandatory SAP master data fields (`NAME1`, `LAND1`, `BUKRS`, `AKONT`, `WAERS`). Classify defects into `AUTO_FIXABLE` (e.g., payment method defaults) vs. `MANUAL_FIX` (e.g., missing Tax ID).



3. **Multi-Field Tax Resolution:** Never validate `STCD1` alone. Run a composite rule across `STCD1`, `STCD2`, `STCD3` (India GST), and `STCEG` (EU VAT) based on the country code (`LAND1`).


4. **Cross-Field Validation:** Validate postal codes (`PSTLZ`) using regex formats strictly mapped to the country code (`LAND1`) (e.g., UK alphanumeric vs. German 5-digit).


5. **Cross-Table Referential Integrity:** Detect orphaned child records (e.g., `LFB1 / KNVV` records whose key does not exist in `LFA1 / KNA1`). -->



---

<!-- #### **Priority 2: Statistical Anomaly Detection (Correctness Pillar)**

*Implement deterministic anomaly detection before sending data to the LLM:*

1. **IQR & Percentile Fencing:** Detect distribution outliers on numeric/duration fields (e.g., Payment Terms `ZTERM` >60 days where 95% of the population is $\le 30$ days, or abnormal Minimum Order Values `MINBW`).


2. **Character & Formatting Anomalies:** Identify illegal characters in legal names (e.g., `#`, `$`, `*`), unclosed parenthesis (e.g., `"Acme Retail (Distribution"`), and malformed email/phone patterns.

 -->

---

<!-- #### **Priority 3: Golden Record Survivorship & Scoring (Extended Cleansing)**

*Upgrade duplicate detection from simple clustering to automated survivorship recommendation:*

1. **Cluster Ranking:** Keep the blocking + fuzzy name/identifier matching engine, but calculate a **Record Quality Score (0–100%)** for each record in a cluster:


$$\text{Quality Score} = (\% \text{ Non-Null Fields}) \times 0.5 + (\text{Active Status}) \times 0.3 + (\text{Recent } ERDAT) \times 0.2$$



2. **Automated Recommendation:** Automatically designate the highest-scoring record as the **Candidate Golden Record** and propose the remaining records to be merged or blocked. -->



---

<!-- #### **Priority 4: Downstream Agent Handoff (Pipeline Integration)**

*The Profiling Agent must feed downstream agents, not terminate at a UI screen:*

1. **Distinct Domain Value Extraction:** Extract all distinct categorical values and frequencies (e.g., `LAND1`, `ZTERM`, `INCO1`, `SPRAS`) into a structured JSON payload for the **Value Mapping Agent**.


2. **Field Metadata Signatures:** Output detected data types, maximum character lengths, and regex patterns per column to feed confidence scores for the **Data Mapping Agent**.
 -->


---

#### **Priority 5: Composite Data Quality (DQ) Scorecard**

*Provide an executive-level quality metric per table and migration object:*

1. Compute weighted scores (0–100%) across the **4 Pillars**:


* $\text{Completeness Score} = \text{Non-null mandatory cells} / \text{Total mandatory cells}$

* $\text{Activeness Score} = \text{Active records} / \text{Total records}$

* $\text{Uniqueness Score} = 1 - (\text{Duplicate records} / \text{Total records})$

* $\text{Correctness Score} = 1 - (\text{Anomaly defects} / \text{Total evaluated cells})$



2. Output an overall **Composite DQ Index** per table to display on the dashboard.

---
#### **Direct Code Mapping Behind Each Priority:**
5. **Priority 5 (Composite DQ Scorecard):**

* *In your code:* In `review_app/main.py` (lines 246–255, `@app.get("/api/stats")`) and `app.js`, the stats endpoint only computes: `total_findings`, `critical`, `high`, `pending`, and `approved`. There is no mathematical score (0–100%) for Completeness, Correctness, or overall Data Quality.



---

#### **Priority 6: Performance & Scalability (1M Benchmark)**

*Prevent out-of-memory crashes on large production datasets:*

1. **Stratified Sampling:** For datasets exceeding 50,000 records, run ydata-profiling/distribution checks on a representative 50k sample.


2. **Full-Scan Aggregations:** Run null checks, exact duplicate detection, and deletion flag counts using native, vectorized Pandas/Polars operations across the full 1M dataset.

---
#### **Direct Code Mapping Behind Each Priority:**
6. **Priority 6 (Performance & 1M Benchmark):**

* *In your code:* In `explorer_agent/data_loader.py` (`load_table`) and `table_profiler.py` (`ProfileReport(df, minimal=True)`), the code executes `pd.read_csv()` and runs `ydata-profiling` directly on the entire in-memory DataFrame with no sampling logic. On a 1-million-row production dataset, this will immediately exhaust memory and crash.


---

#### **Priority 7: Formal Documentation Export (Deliverables)**

*Implement multi-format reporting for business data stewards:*

1. **Excel DQ Defect Report (`.xlsx`):** Detailed, row-level extract containing `[Table, Key_Field, Key_Value, Column, Pillar, Severity, Issue_Description, Recommended_Fix]`.


2. **Executive Summary Profiling Report (`.docx` / `.pdf`):** Formal report containing table statistics, composite DQ scorecards, and high-risk duplicate clusters.

---
#### **Direct Code Mapping Behind Each Priority:**
7. **Priority 7 (Documentation Export):**

* *In your code:* In `review_app/main.py`, there are endpoints to read findings (`/api/findings`), but **zero endpoints** using libraries like `openpyxl` or `python-docx` to export the findings into the Excel/Word/PDF deliverables required by Section 21 of the scoping document.



---

#### **Direct Code Mapping Behind Each Priority:**

<!-- 1. **Priority 1 (Deterministic SAP Domain Rules):**

* *In your code:* In `explorer_agent/graph.py` (lines 35–85), the agent relies entirely on an LLM prompt (`PLANNER_SYSTEM_PROMPT`) to invent Pandas code on the fly for every run.


* *The problem:* Because the LLM invents the code each time, it frequently hallucinates, skips standard SAP check tables, or forgets that Indian GST is in `STCD3` while European VAT is in `STCEG`. The spec mandates hardcoding these deterministic rules so the agent doesn't rely on LLM guesswork for known SAP standards.




2. **Priority 2 (Statistical Anomaly Detection):**

* *In your code:* `graph.py` tells the LLM: *"You can use the built-in helper `detect_distribution_outliers`"*, but inside `table_profiler.py` and `profiler_primitives.py`, that function **does not actually exist** in the primitives. The LLM was being prompted to call a helper that was never implemented. -->


---

#### **Direct Code Mapping Behind Each Priority:**

<!-- 3. **Priority 3 (Golden Record Survivorship):**

* *In your code:* In `duplicate_detector.py` and `schemas.py`, the engine finds duplicate pairs using fuzzy similarity, but in `review_app/main.py` (`set_cluster_verdict_endpoint`), it leaves the verdict entirely blank for a human to manually pick. There is zero code calculating which record has the highest completeness or most recent `ERDAT`.
 -->

#### **Direct Code Mapping Behind Each Priority:**

<!-- 4. **Priority 4 (Downstream Agent Handoff):**

* *In your code:* In `table_profiler.py`, `ProfileRepo` extracts column summaries, but discards raw distinct domain values (it masks them or truncates them to top 5). The codebase completely isolates profiling in...

* *In your code:* In `table_profiler.py`, `ProfileReport` extracts column summaries, but discards raw distinct domain values (it masks them or truncates them to top 5). The codebase completely isolates profiling in SQLite (`dm_episodic.db`) with no API endpoint or JSON export to hand off distinct codes (`LAND1`, `ZTERM`) to the colleague building the Mapping / Value Mapping agent.
 -->

5. **Priority 5 (Composite DQ Scorecard):**

* *In your code:* In `review_app/main.py` (lines 246–255, `@app.get("/api/stats")`) and `app.js`, the stats endpoint only computes: `total_findings`, `critical`, `high`, `pending`, and `approved`. There is no mathematical score (0–100%) for Completeness, Correctness, or overall Data Quality.



6. **Priority 6 (Performance & 1M Benchmark):**

* *In your code:* In `explorer_agent/data_loader.py` (`load_table`) and `table_profiler.py` (`ProfileReport(df, minimal=True)`), the code executes `pd.read_csv()` and runs `ydata-profiling` directly on the entire in-memory DataFrame with no sampling logic. On a 1-million-row production dataset, this will immediately exhaust memory and crash.



7. **Priority 7 (Documentation Export):**

* *In your code:* In `review_app/main.py`, there are endpoints to read findings (`/api/findings`), but **zero endpoints** using libraries like `openpyxl` or `python-docx` to export the findings into the Excel/Word/PDF deliverables required by Section 21 of the scoping document.


---

*The technical specification was tailored specifically to fix what is missing or broken in your exact Python files and LangGraph nodes.*



Extract → Structural profiling → Mapping Agent → Semantic profiling (DQ rules) → Cleansing Agent
           (no meaning needed)    (field + value   (SAP rules, anomalies,          (uses the merge map,
            = Priority 4 output)   mapping)          duplicates, golden record)     findings, value maps)