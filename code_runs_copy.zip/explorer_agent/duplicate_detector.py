"""Deterministic duplicate detection - the matching engine, not the rule author.

Duplicate matching used to depend on the planner LLM remembering to call a
clustering helper from generated ``detail_code``; in practice it rarely did,
so DUPLICATE findings arrived with no rows to review while still costing
planner/reflector tokens. Duplicates are now detected here for every table,
by the deterministic engine below, and the planner is told not to propose
DUPLICATE checks at all.

WHICH columns the engine may use is a separate question with a separate answer:
the LLM drafts that rule spec once per client and schema from the data
dictionary and sanitized statistics (``duplicate_rule_planner``), it is saved
(``memory.duplicate_rule_store``), and ``duplicate_rules.resolve_rules`` hands
it to this module on every later run without any LLM call. Nothing in this file
decides what a column means.

Every table is checked for identical rows, and for repeated values of a key the
dictionary marks as a primary key (both EXACT). Beyond that, matching is
evidence based. Two records (with different business keys) are linked only
when at least one of these holds:

* EXACT    - they share a strong identifier (tax ID, e-mail, phone, IBAN,
             bank key + account, ...), or have the same normalized name AND
             agree on at least two location fields.
* PROBABLE - same normalized name and at least one matching location field,
             or a fuzzy name match >= 90% corroborated by a location field.
* SIMILAR  - fuzzy name match between the configured threshold and 90% with a
             matching location field, or the same name in a different place.

Guards against the noise the old helper produced:

* Names whose numbers differ ("Plant 1" vs "Plant 2") never fuzzy-match.
* Placeholder identifiers ("INVALIDIBAN", "N/A", "0000000", ...) and values
  shared by more than ``max_identifier_share`` records are ignored - a value
  that many records share is a default, not an identity.
* Candidates come from blocking (identifier / name / location indexes), so
  every candidate pair is compared regardless of row order, without an
  all-pairs scan.

Row-level output goes only to the local SQLite store and the review UI - it is
never sent to an LLM (same rule as ``detail_code``).
"""

import json
import re
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from . import client_knowledge, duplicate_rules
from .config import Config
from .logging_config import get_logger
from .profiler_primitives import fuzzy_token_similarity, normalize_text, normalize_text_series

logger = get_logger("duplicate_detector")

MATCH_RANK = {"EXACT": 3, "PROBABLE": 2, "SIMILAR": 1}
# Per-table stats of this process's last detection (incl. groups settled in earlier
# runs, which produce no rows) - read by the scorecard.
LAST_STATS: Dict[str, Dict[str, Any]] = {}
_PROBABLE_NAME_SIMILARITY = 90.0

_PLACEHOLDER_RE = re.compile(
    r"^(invalid.*|n/?a|none|null|nil|tbd|unknown|test.*|dummy.*|x+|0+|9+|(.)\2+)$",
    re.IGNORECASE,
)
_MIN_IDENTIFIER_LEN = 5
_MIN_NAME_LEN = 4


# ---------------------------------------------------------------------------
# Normalization
# ---------------------------------------------------------------------------

def _clean(value: Any) -> str:
    if value is None or (not isinstance(value, str) and pd.isna(value)):
        return ""
    return str(value).strip()


def _normalize_identifier(value: Any) -> str:
    raw = _clean(value)
    if not raw:
        return ""
    norm = re.sub(r"[\s\-./()+_]", "", raw).upper()
    if len(norm) < _MIN_IDENTIFIER_LEN or _PLACEHOLDER_RE.match(raw) or _PLACEHOLDER_RE.match(norm):
        return ""
    return norm


def _normalize_location(value: Any) -> str:
    return normalize_text(_clean(value))


def _numeric_tokens(norm_name: str) -> frozenset:
    return frozenset(re.findall(r"\d+", norm_name))


# Column-wide versions of the above: one vectorized pass per column instead of one
# Python call per cell, with the same result value for value.

def _clean_series(values: pd.Series) -> pd.Series:
    """_clean for a whole column (positional index, so string ops never realign)."""
    s = pd.Series(values.to_numpy(dtype=object), dtype=object)
    return s.where(s.notna(), "").astype(str).str.strip()


def _identifier_series(raw: pd.Series) -> pd.Series:
    """_normalize_identifier for a whole column of _clean_series values."""
    norm = raw.str.replace(r"[\s\-./()+_]", "", regex=True).str.upper()
    placeholder = dict(pat=_PLACEHOLDER_RE.pattern, flags=_PLACEHOLDER_RE.flags)
    bad = ((raw == "") | (norm.str.len() < _MIN_IDENTIFIER_LEN)
           | raw.str.match(**placeholder) | norm.str.match(**placeholder))
    return norm.where(~bad, "")


def _shared_groups(values: np.ndarray, usable: Optional[np.ndarray] = None,
                   sort: bool = False) -> List[List[int]]:
    """Positions of the rows sharing each value that 2+ usable rows hold.

    Groups come in order of first appearance (``sort=True``: in value order) with
    positions ascending - the order a dict filled row by row gives - without one
    Python list per row on a million-row table.
    """
    pos = np.arange(len(values)) if usable is None else np.flatnonzero(usable)
    if len(pos) < 2:
        return []
    codes, _ = pd.factorize(values[pos], sort=sort)
    multi = np.bincount(codes)[codes] > 1
    pos, codes = pos[multi], codes[multi]
    if not len(pos):
        return []
    order = np.argsort(codes, kind="stable")
    pos, codes = pos[order], codes[order]
    return [g.tolist() for g in np.split(pos, np.flatnonzero(np.diff(codes)) + 1)]


class _Records:
    """Per-row matching values held as columns; the full record (display values,
    record id for remembered decisions, ...) is built only for rows that end up in a
    candidate pair. One dict per row cost more memory than the table itself at 1M rows."""

    def __init__(self, df: pd.DataFrame, key_cols: List[str], name_col: Optional[str],
                 location_cols: List[str], identifiers: List[List[str]], display_cols: List[str]):
        n = len(df)
        self.index = df.index
        self.display_cols = display_cols
        self.identifiers = identifiers
        self.location_cols = location_cols
        wanted = set(display_cols) | {c for cols in identifiers for c in cols} | ({name_col} if name_col else set())
        self.raw = {c: df[c].to_numpy(dtype=object) for c in wanted}
        self.name_col = name_col

        if key_cols:
            parts = [_clean_series(df[c]) for c in key_cols]
            keys = parts[0].str.cat([p.to_numpy() for p in parts[1:]], sep=" / ") if len(parts) > 1 else parts[0]
            keys = keys.to_numpy(dtype=object)
            for p in np.flatnonzero((pd.Series(keys).str.strip(" /") == "").to_numpy()):
                keys[p] = f"row {p + 1}"
        else:
            keys = np.array([f"row {p + 1}" for p in range(n)], dtype=object)
        self.keys = keys

        if name_col:
            norm = normalize_text_series(_clean_series(df[name_col]))
            self.norm_names = norm.where(norm.str.len() >= _MIN_NAME_LEN, "").to_numpy(dtype=object)
        else:
            self.norm_names = np.full(n, "", dtype=object)
        self.location = {c: normalize_text_series(_clean_series(df[c])).to_numpy(dtype=object)
                         for c in location_cols}
        per_col = {c: _identifier_series(_clean_series(df[c]))
                   for c in {c for cols in identifiers for c in cols}}
        self.ident: Dict[str, np.ndarray] = {}
        for cols in identifiers:
            parts = [per_col[c] for c in cols]
            joined = parts[0].str.cat([p.to_numpy() for p in parts[1:]], sep="|") if len(parts) > 1 else parts[0]
            complete = np.logical_and.reduce([(p != "").to_numpy() for p in parts])
            self.ident[" + ".join(cols)] = joined.where(complete, "").to_numpy(dtype=object)
        self._numbers: Optional[np.ndarray] = None
        self._cache: Dict[int, Dict[str, Any]] = {}

    def numbers(self) -> np.ndarray:
        """One code per row for its name's set of numbers (equal code == equal set)."""
        if self._numbers is None:
            sets = pd.Series(self.norm_names).str.findall(r"\d+").map(lambda t: " ".join(sorted(set(t))))
            self._numbers = pd.factorize(sets.to_numpy())[0]
        return self._numbers

    def __getitem__(self, p: int) -> Dict[str, Any]:
        rec = self._cache.get(p)
        if rec is None:
            idx = self.index[p]
            display = {c: _clean(self.raw[c][p]) for c in self.display_cols}
            norm_name = self.norm_names[p]
            rec = self._cache[p] = {
                "pos": p,
                "row_index": int(idx) if str(idx).lstrip("-").isdigit() else p,
                "key": self.keys[p],
                "name": _clean(self.raw[self.name_col][p]) if self.name_col else "",
                "norm_name": norm_name,
                "numbers": _numeric_tokens(norm_name),
                "location": {c: self.location[c][p] for c in self.location_cols},
                "identifiers": {label: values[p] for label, values in self.ident.items()},
                "raw_identifiers": {" + ".join(cols): " / ".join(_clean(self.raw[c][p]) for c in cols)
                                    for cols in self.identifiers},
                "display": display,
                "record_id": client_knowledge.record_id(self.keys[p], display),
            }
        return rec


# ---------------------------------------------------------------------------
# Detection
# ---------------------------------------------------------------------------

class _UnionFind:
    def __init__(self, n: int):
        self.parent = list(range(n))

    def find(self, i: int) -> int:
        while self.parent[i] != i:
            self.parent[i] = self.parent[self.parent[i]]
            i = self.parent[i]
        return i

    def union(self, i: int, j: int) -> None:
        ri, rj = self.find(i), self.find(j)
        if ri != rj:
            self.parent[ri] = rj


def find_duplicate_groups(df: pd.DataFrame, rules: Dict[str, Any],
                          decisions: Optional[Dict[str, Dict[str, Any]]] = None,
                          ) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """Return (detail rows for finding_items, summary stats) for one table.

    ``decisions`` are the client's remembered duplicate decisions for this table
    (client_knowledge.load_duplicate_decisions): pairs reviewed as UNIQUE are not
    linked, and DUPLICATE / TO_BE_CONFIRMED verdicts are pre-filled.
    """
    decisions = decisions or {}
    key_cols = [c for c in rules["key"] if c in df.columns]
    key_label = " + ".join(key_cols) or "Row"
    location_cols = [c for c in rules["location"] if c in df.columns]
    # A name match needs location fields to confirm it - without them, names aren't used.
    name_col = rules["name"] if rules["name"] in df.columns and location_cols else None
    identifiers = [cols for cols in rules["identifiers"] if all(c in df.columns for c in cols)]
    display_cols = [c for c in (rules["display"] or list(df.columns)) if c in df.columns and c not in key_cols]

    max_share = Config.DUPLICATE_MAX_IDENTIFIER_SHARE
    fuzzy_threshold = Config.DUPLICATE_FUZZY_NAME_THRESHOLD
    max_block = Config.DUPLICATE_MAX_BLOCK_SIZE

    records = _Records(df, key_cols, name_col, location_cols, identifiers, display_cols)
    keys, norm_names = records.keys, records.norm_names

    # pair (i, j) -> evidence
    evidence: Dict[Tuple[int, int], Dict[str, Any]] = {}

    def add_pair(i: int, j: int) -> Optional[Dict[str, Any]]:
        if keys[i] == keys[j]:
            return None  # same business object (e.g. two bank rows of one vendor)
        pair = (min(i, j), max(i, j))
        return evidence.setdefault(pair, {"identifiers": []})

    skipped_shared: Dict[str, int] = {}

    # 1. Shared strong identifiers
    for label, values in records.ident.items():
        for members in _shared_groups(values, values != ""):
            distinct_keys = {keys[m] for m in members}
            if len(distinct_keys) < 2:
                continue
            if len(distinct_keys) > max_share:
                skipped_shared[label] = skipped_shared.get(label, 0) + 1
                continue
            for a_pos, a in enumerate(members):
                for b in members[a_pos + 1:]:
                    ev = add_pair(a, b)
                    if ev is not None:
                        ev["identifiers"].append(label)

    # 2. Same normalized name (any row order, no window)
    if name_col:
        for members in _shared_groups(norm_names, norm_names != ""):
            distinct_keys = {keys[m] for m in members}
            if len(distinct_keys) < 2:
                continue
            if len(distinct_keys) > max_share:
                # A name that many records share ("Orphan Vendor", "One-time vendor")
                # is a generic placeholder, not evidence of duplication.
                skipped_shared[name_col] = skipped_shared.get(name_col, 0) + 1
                continue
            for a_pos, a in enumerate(members):
                for b in members[a_pos + 1:]:
                    add_pair(a, b)

    # 3. Fuzzy names, only within a shared location block
    if name_col and location_cols:
        # (location column, value) blocks in the order a row-by-row scan meets them
        has_name = norm_names != ""
        blocks = sorted(((members[0], ci, members)
                         for ci, c in enumerate(location_cols)
                         for members in _shared_groups(records.location[c],
                                                       has_name & (records.location[c] != ""))),
                        key=lambda b: (b[0], b[1]))
        numbers = records.numbers()
        oversized = 0
        for _, _, members in blocks:
            if len(members) > max_block:
                # Sub-block by first letter of the name to keep comparisons bounded.
                sub: Dict[str, List[int]] = {}
                for m in members:
                    sub.setdefault(norm_names[m][0], []).append(m)
                groups = list(sub.values())
            else:
                groups = [members]
            for group in groups:
                if len(group) > max_block:
                    oversized += 1
                    continue
                for a_pos, a in enumerate(group):
                    for b in group[a_pos + 1:]:
                        if numbers[a] != numbers[b]:
                            continue
                        if (min(a, b), max(a, b)) in evidence:
                            continue
                        if fuzzy_token_similarity(norm_names[a], norm_names[b]) >= fuzzy_threshold:
                            add_pair(a, b)
        if oversized:
            logger.warning("Skipped fuzzy name matching in %d oversized location block(s) (> %d rows)",
                           oversized, max_block)

    for label, count in skipped_shared.items():
        logger.info("Ignored %d %s value(s) shared by more than %d records (treated as placeholders)",
                    count, label, max_share)

    # Classify each candidate pair, skipping pairs a reviewer already called unique
    links: Dict[Tuple[int, int], Tuple[str, float, str]] = {}
    suppressed = 0

    def link(i: int, j: int, classified: Tuple[str, float, str]) -> None:
        nonlocal suppressed
        if client_knowledge.is_known_not_duplicate(decisions, records[i]["record_id"], records[j]["record_id"]):
            suppressed += 1
            return
        pair = (min(i, j), max(i, j))
        if pair not in links or MATCH_RANK[classified[0]] >= MATCH_RANK[links[pair][0]]:
            links[pair] = classified

    for (i, j), ev in evidence.items():
        classified = _classify_pair(records[i], records[j], ev, location_cols, fuzzy_threshold)
        if classified:
            link(i, j, classified)

    # Row-level duplicates that don't depend on names/identifiers, so every table
    # gets them. These bypass the same-key rule on purpose (star-linked to the
    # first row so a large group doesn't create n^2 pairs).
    if rules.get("key_unique") and key_cols:
        # Group only the rows whose key repeats (a groupby of a million unique keys
        # builds a million index arrays).
        key_frame = df[key_cols].reset_index(drop=True)
        repeated = np.flatnonzero((key_frame.notna().all(axis=1) & key_frame.duplicated(keep=False)).to_numpy())
        key_groups = key_frame.iloc[repeated].groupby(key_cols, dropna=True, sort=False).indices
        for key_value, positions in key_groups.items():
            if len(positions) > 1:
                positions = repeated[positions]
                shown = " / ".join(map(str, key_value)) if isinstance(key_value, tuple) else key_value
                for p in positions[1:]:
                    link(int(positions[0]), int(p),
                         ("EXACT", 100.0, f"same {key_label} '{shown}' - the key should be unique"))
    row_hashes = pd.util.hash_pandas_object(df, index=False).to_numpy()
    for positions in _shared_groups(row_hashes, sort=True):
        for p in positions[1:]:
            link(positions[0], p, ("EXACT", 100.0, f"identical rows - all {df.shape[1]} columns are equal"))

    empty_stats = {"groups": 0, "records": 0, "EXACT": 0, "PROBABLE": 0, "SIMILAR": 0,
                   "suppressed_pairs": suppressed, "remembered_records": 0}
    if not links:
        return [], empty_stats

    uf = _UnionFind(len(df))
    for i, j in links:
        uf.union(i, j)
    cluster_members: Dict[int, set] = {}
    cluster_links: Dict[int, list] = {}
    for pair, link in links.items():
        root = uf.find(pair[0])
        cluster_members.setdefault(root, set()).update(pair)
        cluster_links.setdefault(root, []).append((pair, link))

    assembled = []
    for root, members in cluster_members.items():
        member_links = cluster_links[root]
        best_type = max((t for _, (t, _, _) in member_links), key=lambda t: MATCH_RANK[t])
        best_score = max(s for _, (_, s, _) in member_links)
        assembled.append((members, member_links, best_type, best_score))
    assembled.sort(key=lambda c: (MATCH_RANK[c[2]], c[3], len(c[0])), reverse=True)

    # Groups a reviewer already fully decided in an earlier run are not shown again
    # (duplicates.hide_decided_groups): re-detecting them costs nothing, re-reviewing
    # them costs the reviewer's time. A new member or changed record brings one back.
    settled = settled_records = settled_duplicates = 0
    settled_rows: List[Dict[str, Any]] = []
    if Config.DUPLICATE_HIDE_DECIDED_GROUPS and decisions:
        open_groups = []
        for group in assembled:
            ids = [records[m]["record_id"] for m in group[0]]
            if client_knowledge.is_settled_group(decisions, ids):
                settled += 1
                settled_records += len(ids)
                # Still duplicates in the data - the scorecard must keep counting them: all
                # members but the ones kept as UNIQUE (at least one). Counted this way, not
                # per DUPLICATE verdict, because fully identical rows share one record id and
                # their UNIQUE / DUPLICATE decisions overwrite each other in memory.
                kept = len({i for i in ids if decisions[i]["verdict"] == "UNIQUE"})
                settled_duplicates += len(ids) - max(1, kept)
                # ...and which rows they are, for record readiness: DUPLICATE decisions,
                # keeping one row when identical rows overwrote each other's verdicts.
                dup_members = [m for m in sorted(group[0]) if decisions[records[m]["record_id"]]["verdict"] == "DUPLICATE"]
                if not kept and dup_members:
                    dup_members = dup_members[1:]
                for m in dup_members:
                    decision = decisions[records[m]["record_id"]]
                    settled_rows.append({"row_index": records[m]["row_index"], "key": records[m]["key"],
                                         "merge_into": decision.get("merge_into"), "action": decision.get("action")})
            else:
                open_groups.append(group)
        assembled = open_groups
    empty_stats.update(settled_groups=settled, settled_records=settled_records,
                       settled_duplicates=settled_duplicates, settled_duplicate_rows=settled_rows)
    if not assembled:
        return [], empty_stats

    max_groups = Config.DUPLICATE_MAX_GROUPS
    if len(assembled) > max_groups:
        logger.warning("Found %d duplicate groups; keeping the strongest %d (duplicates.max_groups)",
                       len(assembled), max_groups)
        assembled = assembled[:max_groups]

    rows: List[Dict[str, Any]] = []
    stats = {**empty_stats, "groups": len(assembled)}
    for g_num, (members, member_links, group_type, group_score) in enumerate(assembled, 1):
        group_id = f"DUP-{g_num:03d}"
        stats[group_type] += 1
        stats["records"] += len(members)
        for m in sorted(members, key=lambda p: keys[p]):
            own = [(pair, link) for pair, link in member_links if m in pair]
            own.sort(key=lambda x: (MATCH_RANK[x[1][0]], x[1][1]), reverse=True)
            m_type, m_score, _ = own[0][1]
            reasons = []
            for pair, (_, _, reason) in own[:3]:
                other = records[pair[1] if pair[0] == m else pair[0]]
                reasons.append(f"vs {key_label} {other['key']}: {reason}")
            if len(own) > 3:
                reasons.append(f"and {len(own) - 3} more match(es) in this group")
            rec = records[m]
            row = {
                "row_index": rec["row_index"],
                "key_field": key_label,
                "key_value": rec["key"],
                "issue_detail": f"Possible duplicate ({m_type} {m_score:g}%) - " + "; ".join(reasons),
                "duplicate_group_id": group_id,
                "similarity_score": m_score,
                "match_type": m_type,
                "match_reasons": "; ".join(reasons),
                "review_verdict": "PENDING",
                "record_data": rec["display"],
            }
            remembered = client_knowledge.carried_verdict(
                decisions, rec["record_id"], [records[o]["record_id"] for o in members if o != m])
            if remembered:
                row.update({
                    "review_verdict": remembered["verdict"],
                    "is_golden_record": bool(remembered.get("survivor")),
                    "decision_source": "REMEMBERED",
                    "reviewed_at": remembered["decided_at"],
                    "reviewer_comment": f"Remembered from an earlier review (run {remembered['run_id'][:8]})",
                })
                stats["remembered_records"] += 1
            rows.append(row)
    return rows, stats


def _classify_pair(a: Dict[str, Any], b: Dict[str, Any], ev: Dict[str, Any],
                   location_cols: List[str], fuzzy_threshold: float) -> Optional[Tuple[str, float, str]]:
    same_location = [c for c in location_cols if a["location"][c] and a["location"][c] == b["location"][c]]
    location_text = ", ".join(f"same {c}" for c in same_location)

    if ev["identifiers"]:
        shared = "; ".join(f"same {label} ({a['raw_identifiers'][label]})" for label in ev["identifiers"])
        return "EXACT", 100.0, shared + (f"; {location_text}" if location_text else "")

    if not (a["norm_name"] and b["norm_name"]):
        return None

    if a["norm_name"] == b["norm_name"]:
        if len(same_location) >= 2:
            return "EXACT", 100.0, f"same name '{a['name']}'; {location_text}"
        if same_location:
            return "PROBABLE", 95.0, f"same name '{a['name']}'; {location_text}"
        return "SIMILAR", 75.0, f"same name '{a['name']}' but different location"

    if a["numbers"] != b["numbers"] or not same_location:
        return None
    similarity = fuzzy_token_similarity(a["norm_name"], b["norm_name"])
    if similarity < fuzzy_threshold:
        return None
    match_type = "PROBABLE" if similarity >= _PROBABLE_NAME_SIMILARITY else "SIMILAR"
    return match_type, similarity, f"similar names ({similarity:g}%: '{a['name']}' vs '{b['name']}'); {location_text}"


# ---------------------------------------------------------------------------
# Finding assembly (same dict shape graph.py produces for LLM findings)
# ---------------------------------------------------------------------------

_UNDISPLAYED_RULE_KEYS = ("why", "checks", "source", "source_detail", "notes")


def describe_rules(table_name: str, rules: Dict[str, Any]) -> str:
    """The 'View Matching Rules' text: what is checked, and why each column was used."""
    lines = [
        "# Deterministic duplicate matching - the rules below are applied in plain Python.",
        f"# Rules for {table_name}: {rules['source_detail']}.",
        "",
        "Checks:",
        *(f"  - {c}" for c in rules["checks"]),
    ]
    if rules.get("notes"):
        lines += ["", f"Note: {rules['notes']}"]
    if rules.get("why"):
        lines += ["", "Columns used:", *(f"  - {col}: {reason}" for col, reason in rules["why"].items())]
    lines += ["", "Rules:",
              json.dumps({k: v for k, v in rules.items() if k not in _UNDISPLAYED_RULE_KEYS}, indent=2)]
    return "\n".join(lines)


def detect_table_duplicates(table_name: str, df: pd.DataFrame, client_id: Optional[str] = None,
                            dictionary: Optional[Dict[Tuple[str, str], str]] = None,
                            client_name: Optional[str] = None,
                            rule_planner=None) -> Optional[Dict[str, Any]]:
    """Build one DUPLICATE finding (with all group rows) for any table, or None.

    Rules are resolved by ``duplicate_rules.resolve_rules``: a config.yaml
    override, this client's saved rules, or - for a table/schema never seen for
    this client - one LLM call through ``rule_planner`` using ``dictionary``
    (data_loader.load_data_dictionary), after which they are saved. With a
    ``client_id``, that client's remembered decisions are applied as well (see
    client_knowledge): known-unique pairs are skipped and earlier verdicts
    pre-filled.
    """
    if not Config.DUPLICATES_ENABLED or df.empty:
        return None
    rules = duplicate_rules.resolve_rules(table_name, df, dictionary, client_id=client_id,
                                          client_name=client_name, rule_planner=rule_planner)
    logger.info("[%s] duplicate rules (%s): %s", table_name, rules["source"], "; ".join(rules["checks"]))

    decisions = client_knowledge.load_duplicate_decisions(client_id, table_name)
    rows, stats = find_duplicate_groups(df, rules, decisions)
    LAST_STATS[table_name] = stats
    if not rows and stats.get("settled_groups"):
        logger.info("[%s] all %d duplicate group(s) were fully decided in earlier runs - nothing new to review",
                    table_name, stats["settled_groups"])
    logger.info("[%s] duplicate detection: %d group(s), %d record(s) (EXACT=%d PROBABLE=%d SIMILAR=%d) | "
                "client=%s remembered decisions=%d, unique pairs skipped=%d, verdicts pre-filled=%d",
                table_name, stats.get("groups", 0), stats.get("records", 0),
                stats.get("EXACT", 0), stats.get("PROBABLE", 0), stats.get("SIMILAR", 0),
                client_id, len(decisions), stats.get("suppressed_pairs", 0), stats.get("remembered_records", 0))
    if not rows:
        return None

    breakdown = ", ".join(f"{stats[t]} {t.lower()}" for t in ("EXACT", "PROBABLE", "SIMILAR") if stats[t])
    memory_notes = []
    if stats.get("settled_groups"):
        memory_notes.append(f"{stats['settled_groups']} group(s) fully decided in earlier runs not shown again")
    if stats["suppressed_pairs"]:
        memory_notes.append(f"{stats['suppressed_pairs']} pair(s) previously reviewed as unique skipped")
    if stats["remembered_records"]:
        memory_notes.append(f"{stats['remembered_records']} earlier decision(s) pre-filled")
    memory_text = f" {'; '.join(memory_notes).capitalize()}." if memory_notes else ""
    severity = "HIGH" if stats["EXACT"] else ("MEDIUM" if stats["PROBABLE"] else "LOW")

    return {
        "table": table_name,
        "column": " + ".join(rules["key"]) or (rules["name"] or "ROW"),
        "hypothesis": f"{table_name} rows that duplicate each other, checked by: {'; '.join(rules['checks'])}.",
        "check_code": describe_rules(table_name, rules),
        "summary": (f"{stats['groups']} duplicate group(s) covering {stats['records']} {rules['label']} "
                    f"({breakdown}).{memory_text}"),
        "severity": severity,
        "confidence": "HIGH",
        "reusable": False,  # built-in rule, nothing to promote into the skill library
        "category": "DUPLICATE",
        "rule_scope": "UNIVERSAL",
        "industry": None,
        "fix_type": "MANUAL_FIX",
        "auto_fix_value": None,
        "is_anomaly": False,
        "sub_type": None,
        "raw_tool_result": stats,
        "detail_rows": rows,
    }
